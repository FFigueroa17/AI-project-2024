'use client';
import Image from "next/image";
import Link from "next/link";
import { usePathname } from "next/navigation";
const Header = () => {
  const pathname = usePathname();
  return (
    <header className="fixed z-50 top-6 left-6 md:top-12 md:left-32 rounded-2xl flex flex-row gap-6 p-3 bg-slate-600/50">
      <Link href={"/"}>
        <Image
          src={"/logos/reflect-ai-logo.png"}
          alt={"Logo de ReflectAI"}
          width={200}
          height={200}
          className="object-cover w-[30px] h-auto"
        />
      </Link>
      <Link
        href={"/"}
        className="relative hover:text-opacity-75 transition-opacity duration-200 text-slate-200 after:absolute after:bottom-0 after:left-1/2 after:-translate-x-1/2 after:w-1 after:h-1 after:rounded-full after:bg-white after:opacity-0 hover:after:opacity-100 after:transition-opacity after:duration-200"
      >
        {"Inicio"}
      </Link>

      <Link
        href={"/demo"}
        className={`relative hover:text-opacity-75 transition-opacity duration-200 text-slate-200 after:absolute after:-bottom-1 after:left-1/2 after:-translate-x-1/2 after:w-1 after:h-1 after:rounded-full after:bg-white ${
          pathname === "/demo" ? "after:opacity-100" : "after:opacity-0"
        } hover:after:opacity-100 after:transition-opacity after:duration-200`}
      >
        {"Demo"}
      </Link>
    </header>
  );
};

export default Header;
