"use client";

import { Stars } from "@react-three/drei";
import { Canvas } from "@react-three/fiber";
import { useEffect, useRef, useState } from "react";
import {
  useMotionTemplate,
  useMotionValue,
  motion,
  animate,
  AnimatePresence,
} from "framer-motion";
import Image from "next/image";
import { ScrollArea } from "@radix-ui/react-scroll-area";
import ChatInput from "./_components/chat-input";

const COLORS_TOP = ["#13FFAA", "#1E67C6", "#CE84CF", "#DD335C"];

const messageVariants = {
  initial: {
    opacity: 0,
    y: 20,
    scale: 0.95,
  },
  animate: {
    opacity: 1,
    y: 0,
    scale: 1,
    transition: {
      duration: 0.3,
      ease: "easeOut",
    },
  },
  exit: {
    opacity: 0,
    scale: 0.95,
    transition: {
      duration: 0.2,
    },
  },
};

export default function Home() {
  const color = useMotionValue(COLORS_TOP[0]);
  const [messages, setMessages] = useState<Message[]>([]);
  const [isTyping, setIsTyping] = useState(false);

  useEffect(() => {
    animate(color, COLORS_TOP, {
      ease: "easeInOut",
      duration: 200,
      repeat: Infinity,
      repeatType: "mirror",
    });
  }, []);

  // 2. Dentro del componente Home, agregar la referencia
  const scrollAreaRef = useRef<HTMLDivElement>(null);

  const backgroundImage = useMotionTemplate`radial-gradient(125% 125% at 50% 0%, #020617 50%, ${color})`;

  return (
    <motion.section
      style={{
        backgroundImage,
      }}
      className="relative flex min-h-screen items-center justify-center overflow-hidden bg-gray-950 px-4 py-24 gap-12 text-gray-200"
    >
      <div className="rounded-2xl h-[700px] bg-slate-700/50 backdrop-blur w-full max-w-4xl shadow-xl p-10 flex flex-col items-start justify-start gap-6 z-50">
        <ScrollArea className="h-[600px] overflow-auto w-full flex flex-col items-end justify-start gap-6 px-2">
          {/* Chat Header */}
          <Image
            src={"/images/nav-buttons.png"}
            alt={"Nav buttons"}
            width={1920}
            height={1080}
            priority
            className="h-auto mb-4 w-[50px] object-cover self-start  object-center"
          />

          {/* Chat content */}
          <div ref={scrollAreaRef} className="flex-1 w-full overflow-y-auto">
            <AnimatePresence mode="popLayout">
              {messages.length <= 0 && (
                <motion.div
                  className="flex items-center justify-center h-full w-full flex-row gap-2"
                  variants={messageVariants}
                  initial="initial"
                  animate="animate"
                  exit="exit"
                >
                  <Image
                    src={"/logos/reflect-ai-logo.png"}
                    alt={"Logo de ReflectAI"}
                    width={200}
                    height={200}
                    className="object-cover w-[50px] h-auto"
                  />
                  <h1 className="max-w-3xl bg-gradient-to-br from-white to-gray-400 bg-clip-text text-center text-2xl font-medium leading-tight text-transparent sm:text-5xl sm:leading-tight md:text-7xl md:leading-tight">
                    {"ReflectAI"}
                  </h1>
                </motion.div>
              )}
              {messages.map((message) => (
                <motion.div
                  key={message.id}
                  className={`flex ${
                    message.isAI ? "justify-start" : "justify-end"
                  } mb-4`}
                  variants={messageVariants}
                  initial="initial"
                  animate="animate"
                  exit="exit"
                  layout
                >
                  <div
                    className={`flex gap-2 max-w-[80%] items-end ${
                      message.isAI ? "flex-row" : "flex-row-reverse"
                    }`}
                  >
                    {message.isAI && (
                      <Image
                        src={"/logos/reflect-ai-logo.png"}
                        alt={"Logo de ReflectAI"}
                        width={500}
                        height={500}
                        className="object-cover w-[30px] h-[30px]"
                      />
                    )}
                    <div className="flex flex-col gap-2 items-end">
                      {message.image && (
                        <motion.div
                          initial={{ opacity: 0, scale: 0.8 }}
                          animate={{ opacity: 1, scale: 1 }}
                          exit={{ opacity: 0, scale: 0.8 }}
                          className="rounded-tl-2xl rounded-tr-2xl rounded-bl-2xl rounded-br-none overflow-hidden"
                        >
                          <Image
                            src={
                              typeof message.image === "string"
                                ? message.image
                                : ""
                            }
                            alt="Imagen adjunta"
                            width={200}
                            height={200}
                            className="object-cover"
                          />
                        </motion.div>
                      )}
                      <motion.span
                        className={`p-3 ${
                          message.isAI
                            ? "bg-slate-500/70 rounded-tl-2xl rounded-tr-2xl rounded-br-2xl rounded-bl-none"
                            : "bg-slate-700/70 rounded-tl-2xl rounded-tr-2xl rounded-br-none rounded-bl-2xl"
                        }`}
                      >
                        {message.text}
                      </motion.span>
                    </div>
                  </div>
                </motion.div>
              ))}
            </AnimatePresence>

            {isTyping && (
              <div className="flex items-center gap-2">
                <Image
                  src="/logos/reflect-ai-logo.png"
                  alt="AI Avatar"
                  width={30}
                  height={30}
                  className="object-cover w-[30px] h-auto"
                />
                <motion.div
                  initial={{ opacity: 0.5 }}
                  animate={{ opacity: 1 }}
                  transition={{
                    repeat: Infinity,
                    duration: 1,
                    repeatType: "reverse",
                  }}
                  className="bg-slate-700/70 animate-pulse p-3 rounded-tl-2xl rounded-tr-2xl rounded-br-2xl rounded-bl-none"
                >
                  {"Escribiendo..."}
                </motion.div>
              </div>
            )}
          </div>
        </ScrollArea>
        <ChatInput
          setMessages={setMessages}
          setIsTyping={setIsTyping}
          scrollToBottom={() => {
            scrollAreaRef.current?.scrollTo({
              top: scrollAreaRef.current?.scrollHeight + 200,
              behavior: "smooth",
            });
          }}
        />
      </div>

      {/* Canvas */}
      <div className="absolute inset-0 z-0">
        <Canvas>
          <Stars radius={50} count={2500} factor={4} fade speed={2} />
        </Canvas>
      </div>
    </motion.section>
  );
}
