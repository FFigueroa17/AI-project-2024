'use client';

import { Stars } from "@react-three/drei";
import { Canvas } from "@react-three/fiber";
import { useEffect } from "react";
import { FiArrowRight } from "react-icons/fi";
import {
  useMotionTemplate,
  useMotionValue,
  motion,
  animate,
} from "framer-motion";
import Image from "next/image";
import Icon from "@/components/icon";
import Link from "next/link";

const COLORS_TOP = ["#13FFAA", "#1E67C6", "#CE84CF", "#DD335C"];

export default function Home() {
  const color = useMotionValue(COLORS_TOP[0]);

  useEffect(() => {
    animate(color, COLORS_TOP, {
      ease: "easeInOut",
      duration: 10,
      repeat: Infinity,
      repeatType: "mirror",
    });
  }, []);

  const backgroundImage = useMotionTemplate`radial-gradient(125% 125% at 50% 0%, #020617 50%, ${color})`;
  const border = useMotionTemplate`1px solid ${color}`;
  const boxShadow = useMotionTemplate`0px 4px 24px ${color}`;

  return (
    <motion.section
      style={{
        backgroundImage,
      }}
      className="relative flex flex-col md:flex-row min-h-screen items-center justify-center overflow-hidden bg-gray-950 px-8 py-24 gap-24 md:gap-12 text-gray-200"
    >
      <div className="relative z-10 flex flex-col gap-4 mt-14 md:mt-0 items-start justify-center text-left">
        <span className="mb-1.5 inline-block rounded-2xl bg-gray-600/50 px-3 py-1.5 text-sm">
          {"Tus emociones en ideas"}
        </span>
        <div className="flex items-center flex-row gap-2">
          <Image
            src={"/logos/reflect-ai-logo.png"}
            alt={"Logo de ReflectAI"}
            width={200}
            height={200}
            className="object-cover w-[50px] h-auto"
          />
          <h1 className="max-w-3xl bg-gradient-to-br from-white to-gray-400 bg-clip-text text-center text-3xl font-medium leading-tight text-transparent sm:text-5xl sm:leading-tight md:text-7xl md:leading-tight">
            ReflectAI
          </h1>
        </div>
        <p className="my-6 max-w-xl text-left text-base leading-relaxed md:text-lg md:leading-relaxed">
          {
            "Comparte tus emociones e imágenes. ReflectAI te ofrece recomendaciones personalizadas para ayudarte a reflexionar y descubrir nuevas perspectivas."
          }
        </p>
        <motion.button
          style={{
            border,
            boxShadow,
          }}
          whileHover={{
            scale: 1.015,
          }}
          whileTap={{
            scale: 0.985,
          }}
          className="group relative flex w-fit items-center gap-1.5 rounded-2xl bg-gray-950/10 px-4 py-2.5 text-gray-50 transition-colors hover:bg-gray-950/50"
        >
          <Link href="/demo" className="flex-1 flex gap-1.5 justify-center items-center flex-row">
            {"Accede a nuestro demo"}
            <FiArrowRight className="transition-transform group-hover:-rotate-45 group-active:-rotate-12" />
          </Link>
        </motion.button>
      </div>

      <div className="rounded-2xl h-fit md:h-[700px] bg-slate-700/50 backdrop-blur w-full max-w-2xl shadow-xl p-4 md:p-10 flex flex-col items-start justify-start gap-6">
        <Image
          src={"/images/nav-buttons.png"}
          alt={"Nav buttons"}
          width={1920}
          height={1080}
          priority
          className="rounded-tl-2xl rounded-tr-2xl rounded-br-2xl rounded-bl-none h-auto mb-4 w-[50px] object-cover object-center"
        />
        <span className="bg-slate-700/70 p-3 rounded-tl-2xl rounded-tr-2xl rounded-br-2xl rounded-bl-none">
          {
            "Hoy decidí que voy a dedicar más tiempo a cuidar de mí mismo. Lo necesito y lo merezco."
          }
        </span>
        <Image
          src={"/images/happy-person-img.jpg"}
          alt={"Imagen de una persona triste"}
          width={1920}
          height={1080}
          className="rounded-tl-2xl rounded-tr-2xl rounded-br-2xl rounded-bl-none h-auto w-[150px] object-cover object-center"
        />
        <div className="flex flex-row items-end gap-2">
          <Image
            src={"/logos/reflect-ai-logo.png"}
            alt={"Logo de ReflectAI"}
            width={500}
            height={500}
            className="object-cover w-[30px] h-auto"
          />
          <span className="bg-slate-700 p-3 rounded-tl-2xl rounded-tr-2xl rounded-br-2xl rounded-bl-none">
            {
              "Cuidarte es esencial. Una buena opción podría ser escuchar Weightless de Marconi Union, conocida por su efecto relajante, o explorar una clase de yoga en línea como las que ofrece Yoga with Adriene en YouTube."
            }
          </span>
        </div>

        <div className="mt-auto rounded-2xl flex flex-row justify-between items-center p-3 w-full gap-4 bg-slate-600/60">
          <Icon name="attach_file" />
          <span className="mr-auto text-slate-400">{"Hoy me siento..."}</span>
          <Icon name="send" />
        </div>
      </div>

      <div className="absolute inset-0 z-0">
        <Canvas>
          <Stars radius={50} count={2500} factor={4} fade speed={2} />
        </Canvas>
      </div>
    </motion.section>
  );
};
