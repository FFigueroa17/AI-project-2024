/* eslint-disable @typescript-eslint/no-unused-vars */
type Message = {
  id: string;
  text?: string;
  image?: string | File; // Puede ser URL (string) o File
  isAI?: boolean;
};

type ApiResponse = {
  recommendation: string;
};

type RecommendationInput = {
  text: string;
  image: File;
};
