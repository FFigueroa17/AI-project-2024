import { cn } from '@/lib/utils';

interface IconProps {
  name: string;
  className?: string;
}

const Icon = ({ name, className }: IconProps) => {
  return (
    <span className={cn('material-symbols-rounded', className)}>{name}</span>
  );
};

export default Icon;
