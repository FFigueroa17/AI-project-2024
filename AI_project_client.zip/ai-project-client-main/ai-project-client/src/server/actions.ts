'use server';

export async function getRecommendation(data: FormData): Promise<string> {
  try {

    const text = data.get('text') as string;
    const imageFile = data.get('image') as File;

    const formData = new FormData();
    formData.append('text', text);
    if (imageFile) {
      formData.append('image', imageFile);
    }

    const response = await fetch(
      `${process.env.NEXT_PUBLIC_API_URL}/recommendations`,
      {
        method: "POST",
        body: formData,
      }
    );

    if (!response.ok) {
      const errorText = await response.text();
      throw new Error(`Error HTTP ${response.status}: ${errorText}`);
    }

    const jsonResponse = await response.json();
    return jsonResponse;
  } catch (error) {
    if (error instanceof Error) {
      console.error("Error desconocido:", error);
    }
    throw new Error(`Error: ${(error as Error).message}`);
  }
}