import Icon from "@/components/icon";
import { Input } from "@/components/ui/input";
import { zodResolver } from "@hookform/resolvers/zod";
import { useRef, useState } from "react";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { motion } from "motion/react";
import Image from "next/image";
import { Button } from "@/components/ui/button";
import { getRecommendation } from "../../../server/actions";

const ACCEPTED_IMAGE_TYPES = [
  "image/jpeg",
  "image/jpg",
  "image/png",
  "image/webp",
];

const schema = z.object({
  message: z.string().min(1, "El mensaje es requerido"),
  image: z.union([z.string(), z.custom<File>()]).nullable(),
});

type ChatInputProps = {
  setMessages: React.Dispatch<React.SetStateAction<Message[]>>;
  setIsTyping: (isTyping: boolean) => void;
  scrollToBottom: () => void;
};

const ChatInput = ({
  setMessages,
  setIsTyping,
  scrollToBottom,
}: ChatInputProps) => {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [previewImage, setPreviewImage] = useState<string | null>(null);
  const {
    register,
    handleSubmit,
    reset,
    setError,
    setValue,
    formState: { errors, isValid, isSubmitting },
  } = useForm<z.infer<typeof schema>>({
    resolver: zodResolver(schema),
    mode: "onChange",
  });

  // 3. Modificar handleFileChange para validar tipos
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (files && files.length > 0) {
      const file = files[0];

      // Validar tipo de archivo
      if (!ACCEPTED_IMAGE_TYPES.includes(file.type)) {
        console.error("Tipo de archivo no aceptado");
        return;
      }

      // Guardar archivo
      setValue("image", file);

      // Crear preview
      const imageUrl = URL.createObjectURL(file);
      setPreviewImage(imageUrl);

      console.log("Archivo cargado:", {
        name: file.name,
        type: file.type,
        size: file.size,
      });
    }
  };

  const handleAttachClick = () => {
    fileInputRef.current?.click();
  };

  // 2. Actualizar el componente ChatInput
  // Modificar onSubmit en chat-input.tsx
  const onSubmit = async (data: z.infer<typeof schema>) => {
    if(!data.image){
      setError("image", {
        type: "required",
        message: "La imagen es requerida",
      });
      return;
    }
    // Limpiar formulario
    reset({
      message: "",
      image: null,
    });
    setPreviewImage(null);

    if (fileInputRef.current) {
      fileInputRef.current.value = "";
    }
    
    setTimeout(scrollToBottom, 50);
    try {
      setIsTyping(true);

      // Crear FormData
      const formData = new FormData();
      formData.append("text", data.message);

      // Agregar imagen si existe
      if (data.image instanceof File) {
        formData.append("image", data.image);
      }

      // Crear mensaje para preview con URL temporal
      const newMessage: Message = {
        id: Date.now().toString(),
        text: data.message,
        image:
          data.image instanceof File
            ? URL.createObjectURL(data.image)
            : undefined,
      };

      // Actualizar UI con mensaje del usuario
      setMessages((prev) => [...prev, newMessage]);

      // Llamar a la API
      const recommendation = await getRecommendation(formData);

      // Agregar respuesta de la IA
      setMessages((prev) => [
        ...prev,
        {
          id: Date.now().toString(),
          text: recommendation,
          isAI: true,
        },
      ]);
    } catch (error) {
      console.error("Error detallado:", error);
      setMessages((prev) => [
        ...prev,
        {
          id: Date.now().toString(),
          text: "Error al procesar tu mensaje. Por favor, intenta de nuevo.",
          isAI: true,
        },
      ]);
    } finally {
      setIsTyping(false);
    }
  };

  return (
    <div className="flex flex-col gap-4 w-full relative">
      {previewImage && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: 20 }}
          className="absolute left-0 bottom-16 w-32 h-32"
        >
          <Image
            src={previewImage}
            alt="Preview"
            fill
            className="rounded-2xl object-cover"
          />
          <Button
            onClick={() => {
              setPreviewImage(null);
              reset({ image: undefined });
            }}
            className="absolute -top-2 -right-2 bg-slate-800 rounded-2xl p-1 hover:bg-slate-700"
          >
            <Icon name="close" className="text-white" />
          </Button>
        </motion.div>
      )}
      <form
        onSubmit={handleSubmit(onSubmit)}
        className="relative flex mt-auto items-center w-full"
      >
        <input
          type="file"
          accept={ACCEPTED_IMAGE_TYPES.join(",")}
          {...register("image")}
          ref={fileInputRef}
          onChange={handleFileChange}
          className="hidden"
        />
        <div
          onClick={handleAttachClick}
          className={`absolute left-3 top-3.5 cursor-pointer hover:opacity-70 transition-opacity ${
            errors.image ? "text-red-500" : "text-slate-400"
          }`}
        >
          <Icon name="attach_file" className="text-inherit" />
        </div>
        <Input
          type="text"
          {...register("message", { required: "El mensaje es requerido" })}
          placeholder="For now our AI only supports english message..."
          className={`pl-11 pr-10 w-full ${
            errors.message ? "border-red-500" : "text-slate-400"
          }`}
          disabled={isSubmitting}
        />
        <button
          type="submit"
          disabled={isSubmitting || !isValid}
          className="absolute right-3 top-3.5 text-slate-400 disabled:cursor-not-allowed disabled:opacity-70 transition-opacity"
        >
          <Icon name="send" />
        </button>
      </form>
      {(errors.message || errors.image) && (
        <span className="text-xs text-red-500">
          {errors.message?.message?.toString() ||
            errors.image?.message?.toString()}
        </span>
      )}
    </div>
  );
};

export default ChatInput;
